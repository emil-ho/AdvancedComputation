
use [compras]
GO


CREATE FUNCTION Dame_Precio_Articulo 
	(@codigo char(6))
RETURNS money
AS
BEGIN
  
  DECLARE @precio money
  
  SELECT @precio= preunart from articulos 
        WHERE codigart=@codigo
 
  RETURN @precio 
	
END




SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE FUNCTION PedidosPorProveedor   (@codigo char(4))
RETURNS TABLE
AS

RETURN (SELECT count(numped) numero, nombrpro 
      FROM pedidos p, proveedores pr
      WHERE pr.codigpro=@codigo and
      p.codigpro = pr.codigpro 
      GROUP BY nombrpro)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

-- Ejecuci�n
SELECT * from PedidosPorProveedor('0010')



GO
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE FUNCTION Calcular_Pedido   (@codigo int)
RETURNS decimal (10,2)
AS
BEGIN
  
  DECLARE @precio decimal(9,2)
  DECLARE @iva decimal(4,1)
  
  SELECT @precio= sum(totallin) from lineas WHERE numped=@codigo
  
  SELECT @iva=ivaped from pedidos WHERE numped=@codigo
        
  SET @precio= (@precio* (@iva/100))+@precio

  RETURN @precio 
	
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

-- Ejecuci�n
SELECT dbo. Calcular_Pedido (1)

