-- =============================================
-- Evento cuando el stock baje del m�nimo
-- =============================================
use compras
go

CREATE TABLE eventos(
id numeric identity not null primary key,
fecha datetime not null default getdate(),
motivo varchar (200)
)
GO

IF EXISTS (SELECT name 
	   FROM   sysobjects 
	   WHERE  name = N'tr_articulos' 
	   AND 	  type = 'TR')
    DROP TRIGGER tr_articulos 
GO

CREATE TRIGGER tr_articulos ON articulos FOR  UPDATE 
AS BEGIN

if UPDATE(stockart) BEGIN   
 
    INSERT INTO eventos (fecha, motivo)
    SELECT getdate(), 'Stock minimo alcanzado ' + codigart FROM inserted 
        WHERE stockart<=stockmin

  END
END


-- prueba
update articulos set stockart=stockart-1

select * from eventos

delete from eventos



-- =============================================
-- no seleccionar en lineas un art�culo descatalogado
-- =============================================
create  TRIGGER tr_lineas ON dbo.Lineas AFTER  INSERT, UPDATE 
AS  BEGIN

DECLARE @errmsg  char(255) 

      IF (SELECT count(*) FROM inserted i, articulos a 
           WHERE i.codigart=a.codigart and a.fecbaja is not null )>0
        BEGIN	    
  		 SET @errmsg = 'No puede seleccionar un art�culo descatalogado'   
		 RAISERROR (  @errmsg,16,1)
		 ROLLBACK TRANSACTION 
 		 RETURN
        END  
	     
END


-- =============================================
-- dar de baja el art�culo en vez de borrarlo
-- ========================================d=====


CREATE TRIGGER trd_articulos on articulos
INSTEAD OF DELETE
AS
IF @@ROWCOUNT = 0
  RETURN

UPDATE articulos SET fecbaja=getdate()
  FROM articulos JOIN deleted d ON d.codigart = articulos.codigart

