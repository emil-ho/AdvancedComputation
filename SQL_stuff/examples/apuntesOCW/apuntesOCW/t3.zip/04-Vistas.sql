CREATE VIEW dbo.EncabezadoPedido
AS
SELECT     dbo.Pedidos.numped, dbo.Pedidos.fechaped, dbo.Pedidos.codigpro, 
       dbo.Pedidos.ivaped, dbo.Pedidos.fentrped, dbo.Proveedores.nombrpro, 
       dbo.Proveedores.direcpro, dbo.Proveedores.cpostpro, dbo.Proveedores.localpro,
       dbo.Proveedores.telefpro, dbo.Proveedores.faxpro,dbo.Proveedores.procepro,
       dbo.Proveedores.emailpro, dbo.Proveedores.cifpro
FROM        dbo.Proveedores INNER JOIN
                   dbo.Pedidos ON dbo.Proveedores.codigpro = dbo.Pedidos.codigpro


select * from EncabezadoPedido



CREATE VIEW UdsPedidas WITH SCHEMABINDING as
SELECT  A.descrart, sum(unilin) as unidadesPedidas, count_big(*) as nro_orden
FROM dbo.articulos as A inner join dbo.lineas as L on A.codigart=L.codigart
GROUP BY  A.descrart;

CREATE UNIQUE CLUSTERED INDEX cix_MiVistaMaterializada 
    ON dbo.UdsPedidas(descrart);
