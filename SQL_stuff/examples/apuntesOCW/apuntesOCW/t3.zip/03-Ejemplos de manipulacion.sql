INSERT INTO Proveedores (codigpro, cifpro, nombrpro, direcpro, cpostpro, localpro, telefpro, faxpro, procepro)
VALUES ('P005', 'A39144325', 'Angulo Lastra, Antonio', 'Hern�n Cort�s,18', '39002', 'Santander', '(34) 942 202 022', '(34) 942 202 022', 'UE') 

GO


UPDATE Proveedores  SET emailpro='mailto:gil@unican.es'
WHERE codigpro='P004' 

GO


DELETE FROM Proveedores
WHERE localpro='Santander'

GO


SELECT   *   FROM Articulos 

GO

select * from Pedidos
SELECT nombrpro, telefpro    FROM Proveedores 

GO


SELECT *    FROM Articulos
WHERE preunart > 180 AND stockart <= 100 

GO


SELECT *    FROM Articulos
WHERE preunart BETWEEN 180 AND 300 

GO

SELECT codigpro, nombrpro, direcpro, cpostpro, localpro FROM Proveedores
WHERE localpro IN ('Santander', 'Madrid', 'Barcelona') 

GO

SELECT codigpro, nombrpro, direcpro, cpostpro, localpro FROM Proveedores
WHERE nombrpro LIKE '[A-J]%'

go

SELECT codigpro, nombrpro, direcpro, cpostpro, localpro, telefpro 
FROM Proveedores
WHERE emailpro IS NULL 

GO

SELECT DISTINCT Proveedores.codigpro, nombrpro, direcpro, localpro
       FROM Proveedores INNER JOIN Pedidos 
	      ON Proveedores.codigpro = Pedidos.codigpro
      WHERE fechaped BETWEEN '2010/01/20' AND '2010/09/15' 

go




SELECT DISTINCT Articulos.codigart, descrart
    FROM Pedidos INNER JOIN 
                (Lineas  INNER JOIN Articulos ON Lineas.codigart = Articulos.codigart) 
                              ON Pedidos.numped = Lineas.numped 
     WHERE fechaped BETWEEN '15/5/2010' AND '30/05/2010' 

go

SELECT x.numped, x.numlin, x.codigart
FROM Lineas x, Lineas y
WHERE x.numped  = y.numped   AND   x.numlin <> y.numlin
      	AND x.codigart = y.codigart 

GO


SELECT Proveedores.codigpro, nombrpro, Pedidos.numped
    FROM Proveedores LEFT JOIN Pedidos
         ON  Proveedores.codigpro = Pedidos.codigpro 
GO


SELECT Proveedores.codigpro, nombrpro, Pedidos.numped
    FROM Pedidos RIGHT JOIN Proveedores
         ON  Proveedores.codigpro = Pedidos.codigpro 
GO

SELECT Proveedores.codigpro, nombrpro, Pedidos.numped
    FROM Proveedores LEFT JOIN Pedidos
         ON  Proveedores.codigpro = Pedidos.codigpro 
WHERE LOCALPRO='SANTANDER'

GO
SELECT Proveedores.codigpro, nombrpro, Pedidos.numped
    FROM Proveedores LEFT JOIN Pedidos
         ON  Proveedores.codigpro = Pedidos.codigpro 
AND LOCALPRO='SANTANDER'

GO

SELECT articulos.codigart, descrart, stockart FROM Articulos
     WHERE stockart > ALL (SELECT unilin   FROM Lineas 
                                           WHERE Articulos.codigart = Lineas.codigart) 

GO


SELECT DISTINCT Articulos.codigart, descrart   FROM Articulos
    WHERE Articulos.codigart NOT IN (SELECT Lineas.codigart FROM Lineas, Pedidos
                                                                  WHERE Pedidos.numped = Lineas.numped
                                                                        AND Pedidos.fechaped                      
                                                                   BETWEEN '24/09/2010' AND '21/11/2010') 
GO


SELECT DISTINCT Proveedores.codigpro, nombrpro FROM Proveedores
    WHERE  EXISTS  ( SELECT *    FROM Pedidos
                                       WHERE Proveedores.codigpro = Pedidos.codigpro
	                              AND fechaped BETWEEN '24/09/2010' AND '21/11/2010')
	                              AND localpro = 'Madrid' 

GO

SELECT   COUNT(codigart) AS Cantidad,  MAX(preunart) AS Max, 
                  MIN(preunart) AS Min,  AVG(preunart) AS Precio_medio, 
                  SUM(preunart*stockart) AS Valoraci�n
      FROM Articulos 

GO

SELECT numped, fechaped, 
DAY(fechaped) as dia_mes, MONTH(fechaped) as mes, 
YEAR(fechaped) as a�o, DATEPART(dw,fechaped) as dia_sem
FROM Pedidos 

SELECT numped, fechaped, 
DATEPART(dd,fechaped) as dia_mes, DATEPART(mm,fechaped) as mes, 
DATEPART(YY,fechaped) as a�o, DATEPART(DW,fechaped) as dia_sem
FROM Pedidos 

GO

SELECT  numped, numlineas,
         row_number() over (order by numlineas) AS num_fila,  
         rank () over (order by numlineas) AS ranking, 
         dense_rank() over (order by numlineas) AS dense_ranking, 
         ntile(4) over (order by numlineas) as quartil
FROM (SELECT  numped, count(*) numlineas from lineas group by numped) as resultado 


SELECT numped, SUM((preunlin*unilin)*(1-desculin/100)) as Importe
     FROM Lineas
     GROUP BY numped

go


SELECT numped, SUM((preunlin*unilin)*(1-desculin/100)) as Importe
     FROM Lineas
     GROUP BY numped
     HAVING COUNT(*) > 1

go

SELECT descrart, numped, sum(unilin) as unidadesPedidas
FROM articulos inner join lineas on articulos.codigart=lineas.codigart
GROUP BY descrart, numped
WITH CUBE
order by descrart ;

SELECT descrart, numped, sum(unilin) as unidadesPedidas
FROM articulos inner join lineas on articulos.codigart=lineas.codigart
GROUP BY descrart, numped
WITH ROLLUP ;

SELECT numped, numlin
      FROM Lineas
      ORDER BY 1 DESC, 2 DESC 

go



SELECT numped, SUM((preunlin*unilin)*(1-desculin/100)) as Importe
      INTO t1
      FROM Lineas 
      GROUP BY numped 
      HAVING COUNT(*) > 1

go

SELECT codigpro, nombrpro, localpro 
        FROM Proveedores
   UNION
SELECT codigp, nombrp, localp
        FROM Proveedores_Anulados
   ORDER BY 1

go


SELECT codigcli, nombrcli, localcli
        FROM clientes 
EXCEPT
SELECT codigpro, nombrpro, localpro
        FROM Proveedores
GO

SELECT codigcli, nombrcli, localcli
        FROM clientes 
intersect
SELECT codigpro, nombrpro, localpro
        FROM Proveedores
GO


GO


SELECT    'precio' = 
      CASE 
         WHEN preunart IS NULL THEN 'No establecido'
         WHEN preunart < 200 THEN 'Bajo'
      ELSE 'Alto'
      END,
   descrart 
FROM articulos


WITH total_pedidos (numped, valor) as
( SELECT  numped, sum(unilin*preunlin)  from lineas
 group by numped
)
SELECT  numped, valor
from total_pedidos
where total_pedidos.valor>=
             ( select avg(valor) from total_pedidos)


WITH pedidosOrdenados AS
(SELECT numped, fechaped,
ROW_NUMBER() OVER (order by fechaped) as RowNumber
FROM pedidos) 
SELECT * 
FROM pedidosOrdenados 
WHERE RowNumber between 3 and 4;




