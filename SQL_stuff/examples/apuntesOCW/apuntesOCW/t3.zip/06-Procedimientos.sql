CREATE PROCEDURE dameProveedores    AS

SELECT codigpro, nombrpro, direcpro, cpostpro, localpro, telefpro 
FROM Proveedores;
Go


exec dameProveedores;


CREATE PROCEDURE upd_precio_articulo   @ipc decimal(3,2)    AS

BEGIN TRANSACTION

   update articulos set preunart = preunart + (preunart*@ipc/100)
         where preunart is not null

   if @@ERROR <> 0
begin
          ROLLBACK TRANSACTION
          RAISERROR ( 'No se han modificado los precios',16,1)
          RETURN
end

COMMIT TRANSACTION
Go


exec upd_precio_articulo 3.2

CREATE PROCEDURE upd_precio_articulo   @ipc decimal(3,2)    AS

BEGIN TRY
BEGIN TRANSACTION

   update articulos set preunart = preunart + (preunart*@ipc/100) 
             where preunart is not null

COMMIT TRANSACTION
END TRY

BEGIN CATCH
	ROLLBACK TRANSACTION
   RAISERROR ( 'No se han modificado los precios',16,1)
END CATCH

RETURN

exec upd_precio_articulo 3.2

